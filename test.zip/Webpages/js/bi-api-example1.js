$(document).ready(function () {
$('#SubmitA').click(function () {
var MYID = "";
var MYPW = "";
var CLTID = "";
var PERNUM = "";
var sql1 = "";
var url = "";
 MYID = $("#MYID").val();
 MYPW = $("#MYPW").val();
 CLTID = $("#CLTID").val();
 PERNUM = $("#PERNUM").val();
  if(CLTID != "" && CLTID != 'undefined' && PERNUM != "" && PERNUM != 'undefined'){
  sql1 = "select cl_tid, SLS_EM_CLASSIFICATION (CLOSE_BAL_AMT, MON_ON_BOOK_CT, TOTL_PAY_AMT, TOTL_SALES_AMT, UTIL_RATE) as Classification, SLS_EM_EVENTPROBABILITY (CLOSE_BAL_AMT, MON_ON_BOOK_CT, TOTL_PAY_AMT, TOTL_SALES_AMT, UTIL_RATE) (format '+9.99') as Probability from (select cl_tid, per_num, max(close_bal_amt) as close_bal_Amt, max(mon_on_book_ct) as mon_on_book_ct, max(totl_pay_amt) as totl_pay_amt, max(totl_sales_amt) as totl_sales_amt, max(util_rate) as util_rate from lb82443.cl_bill a where cl_tid = " + CLTID + " and per_num = " + PERNUM + " group by cl_tid, per_num) as score";
  }
  else{
  sql1 = "";
  }
  
  url = "https://edwdeveco.nam.nsroot.net:1443/tdrest/systems/EDWDEV/queries"

  $.ajax({
      type: "POST",
      url: url,
      contentType: "application/json",
      headers: {
          'Accept' : "application/vnd.com.teradata.rest-v1.0+json",
          'Authorization': 'Basic ' + btoa(MYID + ':' + MYPW)
      },
      data: JSON.stringify({
          query: sql1,
          format: 'object'
      })
   }).done(function (data)
   {
		$("#SubmitAmessage").text("RESULTS: SUCCESS");
	  buildHtmlTable(data.results[0].data,"#SubmitAresult");
		
		//$.jsontotable(data, { id: "#jsontotable-obj" });
      //$("#message").text("RESULTS: SUCCESS");
      //$("#result").append(JSON.stringify(data, null, 2));
   }).fail (function (error)
   {
      $("#SubmitAmessage").text("RESULTS: ERROR, HTTP Code: " + error.status);
      $("#SubmitAresult").append(JSON.stringify(error.responseJSON, null, 2));
   })

  // $("#query").text("Executing query: " + sql);


});
$('#SubmitB').click(function () {
var MYID = "";
var MYPW = "";
var CLTID2 = "";
var sql2 = "";
var url = "";
 MYID = $("#MYID").val();
 MYPW = $("#MYPW").val();
 CLTID2 = $("#CLTID2").val();
  if(CLTID2 != "" && CLTID2 != 'undefined'){
  sql2 = "select * from lb82443.hdratio where cl_tid = " + CLTID2 + " ";
  }else{
  sql2 = "";
  }
  

  url = "https://edwdeveco.nam.nsroot.net:1443/tdrest/systems/EDWDEV/queries"

  $.ajax({
      type: "POST",
      url: url,
      contentType: "application/json",
      headers: {
          'Accept' : "application/vnd.com.teradata.rest-v1.0+json",
          'Authorization': 'Basic ' + btoa(MYID + ':' + MYPW)
      },
      data: JSON.stringify({
          query: sql2,
          format: 'object'
      })
   }).done(function (data)
   {
      $("#SubmitBmessage").text("RESULTS: SUCCESS");
	  buildHtmlTable(data.results[0].data,"#SubmitBresult");
      //$("#result").append(JSON.stringify(data, null, 2));
   }).fail (function (error)
   {
      $("#SubmitBmessage").text("RESULTS: ERROR, HTTP Code: " + error.status);
      $("#SubmitBresult").append(JSON.stringify(error.responseJSON, null, 2));
   })

   //$("#query").text("Executing query: " + sql);
});

   // Builds the HTML Table out of myList.
function buildHtmlTable(myList,selector) {
    var columns = addAllColumnHeaders(myList, selector);

    for (var i = 0 ; i < myList.length ; i++) {
        var row$ = $('<tr/>');
        for (var colIndex = 0 ; colIndex < columns.length ; colIndex++) {
            var cellValue = myList[i][columns[colIndex]];

            if (cellValue == null) { cellValue = ""; }

            row$.append($('<td/>').html(cellValue));
        }
        $(selector).append(row$);
    }
}

// Adds a header row to the table and returns the set of columns.
// Need to do union of keys from all records as some records may not contain
// all records
function addAllColumnHeaders(myList, selector)
{
    var columnSet = [];
    var headerTr$ = $('<tr/>');

    for (var i = 0 ; i < myList.length ; i++) {
        var rowHash = myList[i];
        for (var key in rowHash) {
            if ($.inArray(key, columnSet) == -1){
                columnSet.push(key);
                headerTr$.append($('<th/>').html(key));
            }
        }
    }
    $(selector).append(headerTr$);

    return columnSet;
}
});
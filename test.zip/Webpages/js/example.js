$(document).ready(function(){
    // Responsive sidebar
    $('#sidebar-trigger').on('click',function(){
        if($('body').hasClass('sidebar-open')) {
            $('body').removeClass('sidebar-open');
        } else {
            $('body').addClass('sidebar-open');
        }
        return false;
    });
});
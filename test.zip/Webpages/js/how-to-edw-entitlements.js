$(document).ready(function () {
$('#SubmitA').click(function () {
var username = 'EDW_API_DEV';
var password = 'Popcorn1';
var SOEID = "";
var sql1 = "";
var url = "";
 SOEID = $("#SOEID").val();
  if(SOEID != "" && SOEID != 'undefined'){
  sql1 = "SELECT GRANTEE AS USERNAME, ROLENAME FROM DBC.ROLEMEMBERS WHERE GRANTEE ='" + SOEID + "' ORDER BY ROLENAME";
  }
  else{
  sql1 = "";
  }
  
  //var sql2 = "'  ORDER BY ROLENAME;"
  
  url = "https://edwdeveco.nam.nsroot.net:1443/tdrest/systems/EDWDEV/queries"

  $.ajax({
      type: "POST",
      url: url,
      contentType: "application/json",
      headers: {
          'Accept' : "application/vnd.com.teradata.rest-v1.0+json",
          'Authorization': 'Basic ' + btoa(username + ':' + password)
      },
      data: JSON.stringify({
          query: sql1,
          format: 'object'
      })
   }).done(function (data)
   {
		$("#SubmitAmessage").text("RESULTS: SUCCESS");
	  buildHtmlTable(data.results[0].data,"#SubmitAresult");
		
		//$.jsontotable(data, { id: "#jsontotable-obj" });
      //$("#message").text("RESULTS: SUCCESS");
      //$("#result").append(JSON.stringify(data, null, 2));
   }).fail (function (error)
   {
      $("#SubmitAmessage").text("RESULTS: ERROR, HTTP Code: " + error.status);
      $("#SubmitAresult").append(JSON.stringify(error.responseJSON, null, 2));
   })

  // $("#query").text("Executing query: " + sql);
    

});
$('#SubmitB').click(function () {
var username = 'EDW_API_DEV';
var password = 'Popcorn1';
var sql1 = "";
var sql1 = "";
var sql1 = "";
var DBNAME = "";
var TBLNAME = "";
var url = "";
   sql1 = "SELECT DATABASENAME, TABLENAME, ROLENAME, ColumnName, CASE WHEN AccessRight ='R' THEN 'SELECT' WHEN AccessRight = 'I' THEN 'INSERT' WHEN AccessRight = 'D' THEN 'DELETE' WHEN AccessRight = 'U' THEN 'UPDATE' ELSE AccessRight END AS Privilege FROM DBC.ALLROLERIGHTS WHERE DatabaseName = '"
   sql2 = "' AND TableName = '"
   sql3 = "' AND RoleName NOT IN ('R_Citi_DBA', 'bkpusers') UNION SELECT DATABASENAME, TABLENAME, ROLENAME, ColumnName, CASE WHEN AccessRight ='R' THEN 'SELECT' WHEN AccessRight = 'I' THEN 'INSERT' WHEN AccessRight = 'D' THEN 'DELETE' WHEN AccessRight = 'U' THEN 'UPDATE' ELSE AccessRight END AS Privilege FROM DBC.ALLROLERIGHTS WHERE DatabaseName = '"
   sql4 = "' AND TableName = 'ALL"
   sql5 = "' AND RoleName NOT IN ('R_Citi_DBA', 'bkpusers') ORDER BY 1,2,3,5;"
   DBNAME = $("#DBNAME").val();
   TBLNAME = $("#TBLNAME").val();
   
   if(DBNAME !="" && DBNAME != 'undefined'){
   DBNAME = DBNAME ;
   }else{
   DBNAME = "";
   }
   
   if(TBLNAME !="" && TBLNAME != 'undefined'){
   TBLNAME = TBLNAME ;
   }else{
   TBLNAME = "";
   }
   
   url = "https://edwdeveco.nam.nsroot.net:1443/tdrest/systems/EDWDEV/queries";

  $.ajax({
      type: "POST",
      url: url,
      contentType: "application/json",
      headers: {
          'Accept' : "application/vnd.com.teradata.rest-v1.0+json",
          'Authorization': 'Basic ' + btoa(username + ':' + password)
      },
      data: JSON.stringify({
          query: sql1.concat(DBNAME).concat(sql2).concat(TBLNAME).concat(sql3).concat(DBNAME).concat(sql4).concat(TBLNAME).concat(sql5),
          format: 'object'
      }),
   }).done(function (data)
   {
      $("#SubmitBmessage").text("RESULTS: SUCCESS");
	  buildHtmlTable(data.results[0].data,"#SubmitBresult");
      //$("#result").append(JSON.stringify(data, null, 2));
   }).fail (function (error)
   {
      $("#SubmitBmessage").text("RESULTS: ERROR, HTTP Code: " + error.status);
      $("#SubmitBresult").append(JSON.stringify(error.responseJSON, null, 2));
   })

   //$("#query").text("Executing query: " + sql);
});



   // Builds the HTML Table out of myList.
function buildHtmlTable(myList,selector) {
    var columns = addAllColumnHeaders(myList, selector);

    for (var i = 0 ; i < myList.length ; i++) {
        var row$ = $('<tr/>');
        for (var colIndex = 0 ; colIndex < columns.length ; colIndex++) {
            var cellValue = myList[i][columns[colIndex]];

            if (cellValue == null) { cellValue = ""; }

            row$.append($('<td/>').html(cellValue));
        }
        $(selector).append(row$);
    }
}

// Adds a header row to the table and returns the set of columns.
// Need to do union of keys from all records as some records may not contain
// all records
function addAllColumnHeaders(myList, selector)
{
    var columnSet = [];
    var headerTr$ = $('<tr/>');

    for (var i = 0 ; i < myList.length ; i++) {
        var rowHash = myList[i];
        for (var key in rowHash) {
            if ($.inArray(key, columnSet) == -1){
                columnSet.push(key);
                headerTr$.append($('<th/>').html(key));
            }
        }
    }
    $(selector).append(headerTr$);

    return columnSet;
}
});
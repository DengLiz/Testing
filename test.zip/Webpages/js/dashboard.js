$(document).ready(function(){
    $('.box-sm .bar').sparkline('html',{
        type:"bar",
        height:"30",
        barWidth:"6",
        barSpacing:"2",
        barColor:"#ffffff",
        negBarColor:"#eeeeee",
        tooltipFormat: '{{offset:offset}} - {{value}}',
        tooltipValueLookups: {
            offset: {
                0: 'January',
                1: 'February',
                2: 'March',
                3: 'April',
                4: 'May',
                5: 'June',
                6: 'July',
                7: 'August'
            }
        }
    });
    $('.box .chart').sparkline('html',{
        type:'line',
        width:"90%",
        height:40,
        lineColor:'#97999b',
        highlightSpotColor:'#84BD00',
        highlightLineColor:'#ED8800',
        fillColor:!1,
        spotColor:!1,
        maxSpotColor:!1,
        minSpotColor:!1,
        spotRadius:2,
        lineWidth:2
    });
    
    var datapie = [
        {label: "Major",  data: 50, color: '#00bdf2'},
        {label: "Medium",  data: 65, color: '#97999b'},
        {label: "Minor",  data: 23, color: '#ccc'}
    ];
    $.plot($("#change-pie"), datapie, { 
        series: {
             pie: {
                 show: true,
                 label: {
                     show: true
                 },
                 innerRadius:.4
            }
        },
        legend: {show: true},
        grid: {
            hoverable: true,
            clickable: true
        }
    });
    $("#change-pie").bind("plotclick", pieClick);

    function pieClick(event, pos, obj) 
    {
            if (!obj)
                    return;
            percent = parseFloat(obj.series.percent).toFixed(2);
            alert(''+obj.series.label+': '+percent+'%');
    }
});
